import React, { useEffect, useState } from "react";
import {
  motion,
  useMotionValue,
  useSpring,
  useScroll,
  useTransform,
  AnimatePresence,
} from "framer-motion";
import { ArrowUpRight, ChevronDown, ChevronUp, Facebook, Globe, Instagram, Linkedin } from "lucide-react";

const MotionA = motion.a;

const EASE_OUT: [number, number, number, number] = [0.16, 1, 0.3, 1];

const fadeUp = {
  hidden: { opacity: 0, y: 24, filter: "blur(8px)" },
  show: (delay = 0) => ({
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { duration: 0.85, ease: EASE_OUT, delay },
  }),
};

/* ── Controlled smooth scrolling (consistent across browsers/iframes) ── */
const easeInOutCubic = (t: number) =>
  t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

let activeScrollRAF: number | null = null;
let activeScrollCleanup: (() => void) | null = null;

function stopSmoothScroll() {
  if (activeScrollRAF !== null) {
    cancelAnimationFrame(activeScrollRAF);
    activeScrollRAF = null;
  }
  if (activeScrollCleanup) {
    activeScrollCleanup();
    activeScrollCleanup = null;
  }
}

function smoothScrollTo(targetY: number, duration = 950) {
  const startY = window.scrollY;
  const maxY = document.documentElement.scrollHeight - window.innerHeight;
  const endY = Math.max(0, Math.min(targetY, maxY));
  const diff = endY - startY;
  if (Math.abs(diff) < 1) return;

  // Cancel any in-flight animation so repeated clicks don't stack.
  stopSmoothScroll();

  // Let the user take over: abort on manual wheel / touch / nav keys.
  const onUserScroll = () => stopSmoothScroll();
  const onKey = (e: KeyboardEvent) => {
    if (["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " "].includes(e.key)) {
      stopSmoothScroll();
    }
  };
  window.addEventListener("wheel", onUserScroll, { passive: true });
  window.addEventListener("touchmove", onUserScroll, { passive: true });
  window.addEventListener("keydown", onKey);
  activeScrollCleanup = () => {
    window.removeEventListener("wheel", onUserScroll);
    window.removeEventListener("touchmove", onUserScroll);
    window.removeEventListener("keydown", onKey);
  };

  let start: number | null = null;
  const step = (timestamp: number) => {
    if (start === null) start = timestamp;
    const progress = Math.min((timestamp - start) / duration, 1);
    window.scrollTo(0, startY + diff * easeInOutCubic(progress));
    if (progress < 1) {
      activeScrollRAF = requestAnimationFrame(step);
    } else {
      stopSmoothScroll();
    }
  };
  activeScrollRAF = requestAnimationFrame(step);
}

function smoothScrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  // Sections carry large decorative top padding; skip it so the heading
  // itself lands in a comfortable, more centered position below the nav.
  const padTop = parseFloat(getComputedStyle(el).paddingTop) || 0;
  const elementTop = el.getBoundingClientRect().top + window.scrollY;
  const gap = Math.min(140, window.innerHeight * 0.16); // breathing room below nav
  const y = elementTop + padTop - gap;
  smoothScrollTo(y);
}

/* ── Glowing section label ────────────────────────────────── */
function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      className="font-sans text-sm font-normal uppercase tracking-[0.2em] text-white/75 cursor-default select-none"
      whileHover={{
        color: "rgba(255,255,255,1)",
        textShadow: "0 0 16px rgba(255,255,255,0.4), 0 0 40px rgba(255,255,255,0.15)",
      }}
      transition={{ duration: 0.4, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
}

/* ── Section scroll arrow ─────────────────────────────────── */
function SectionArrow({ targetId, label }: { targetId: string; label: string }) {
  const scroll = () =>
    smoothScrollToId(targetId);
  return (
    <motion.button
      onClick={scroll}
      className="group flex flex-col items-start gap-2 cursor-pointer focus:outline-none mt-20 md:mt-28"
      aria-label={`Scroll to ${label}`}
    >
      <span className="font-sans text-xs font-normal uppercase tracking-[0.18em] text-white/55 group-hover:text-white/90 transition-colors duration-400">
        {label}
      </span>
      <motion.div
        animate={{ y: [0, 7, 0] }}
        transition={{ duration: 1.9, repeat: Infinity, ease: "easeInOut" }}
        className="text-white/40 group-hover:text-white/80 transition-colors duration-400"
      >
        <ChevronDown className="w-4 h-4" />
      </motion.div>
    </motion.button>
  );
}

/* ── Hero glowing lines background ────────────────────────── */
function HeroGlowLines() {
  const lines = [
    { d: "M-120,430 C320,300 640,560 1520,360", stroke: "url(#hg1)", w: 3.5 },
    { d: "M-120,500 C420,640 820,300 1520,540", stroke: "url(#hg2)", w: 3 },
    { d: "M-120,360 C360,430 720,650 1520,300", stroke: "url(#hg3)", w: 4 },
    { d: "M-120,560 C320,470 920,720 1520,450", stroke: "url(#hg4)", w: 2.5 },
    { d: "M-120,300 C520,540 820,200 1520,620", stroke: "url(#hg5)", w: 3.5 },
    { d: "M-120,620 C420,560 770,840 1520,580", stroke: "url(#hg2)", w: 2 },
    { d: "M-120,250 C460,360 780,520 1520,240", stroke: "url(#hg3)", w: 2 },
  ];
  return (
    <motion.div
      aria-hidden
      className="pointer-events-none absolute inset-0 z-0"
      style={{ filter: "blur(9px)", willChange: "transform", transform: "translateZ(0)" }}
      animate={{ y: [0, -26, 0] }}
      transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
    >
      <svg className="w-full h-full" viewBox="0 0 1400 900" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id="hg1" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#22d3ee" stopOpacity="0" />
            <stop offset="50%" stopColor="#22d3ee" />
            <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="hg2" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#2dd4bf" stopOpacity="0" />
            <stop offset="50%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#2dd4bf" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="hg3" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0" />
            <stop offset="50%" stopColor="#a855f7" />
            <stop offset="100%" stopColor="#d946ef" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="hg4" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0" />
            <stop offset="50%" stopColor="#22d3ee" />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="hg5" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#6366f1" stopOpacity="0" />
            <stop offset="50%" stopColor="#818cf8" />
            <stop offset="100%" stopColor="#a855f7" stopOpacity="0" />
          </linearGradient>
          <filter id="hgGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="5" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        <g filter="url(#hgGlow)">
          {lines.map((l, i) => (
            <motion.path
              key={i}
              d={l.d}
              fill="none"
              stroke={l.stroke}
              strokeWidth={l.w}
              strokeLinecap="round"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 0.85 }}
              transition={{ duration: 2.6, ease: [0.16, 1, 0.3, 1], delay: 0.3 + i * 0.22 }}
            />
          ))}
        </g>
      </svg>
    </motion.div>
  );
}

/* ── Page ─────────────────────────────────────────────────── */
export default function Home() {
  /* cursor */
  const cursorX = useMotionValue(-400);
  const cursorY = useMotionValue(-400);
  const springX = useSpring(cursorX, { stiffness: 70, damping: 22 });
  const springY = useSpring(cursorY, { stiffness: 70, damping: 22 });

  useEffect(() => {
    if (window.matchMedia("(hover: none)").matches) return;
    const move = (e: MouseEvent) => { cursorX.set(e.clientX); cursorY.set(e.clientY); };
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, []);

  /* scroll */
  const { scrollY, scrollYProgress } = useScroll();
  const heroOpacity = useTransform(scrollY, [0, 380], [1, 0]);
  const heroY       = useTransform(scrollY, [0, 380], [0, -55]);
  const heroScale   = useTransform(scrollY, [0, 380], [1, 0.97]);

  /* scroll-to-top visibility */
  const [showTop, setShowTop] = useState(false);
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [lang, setLang] = useState<"en" | "de" | "hr">("en");
  const languages: { code: "en" | "de" | "hr"; label: string; short: string; flag: string }[] = [
    { code: "en", label: "English",  short: "EN", flag: "🇬🇧" },
    { code: "de", label: "Deutsch",  short: "DE", flag: "🇩🇪" },
    { code: "hr", label: "Hrvatski", short: "HR", flag: "🇭🇷" },
  ];
  useEffect(() => {
    const unsub = scrollY.on("change", (v) => setShowTop(v > 600));
    return unsub;
  }, [scrollY]);

  /* lock background scroll while the mobile menu is open */
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  /* close the mobile menu (and release scroll lock) when crossing to desktop */
  useEffect(() => {
    if (!mobileOpen) return;
    const mq = window.matchMedia("(min-width: 768px)");
    const handle = () => {
      if (mq.matches) setMobileOpen(false);
    };
    handle();
    mq.addEventListener("change", handle);
    return () => mq.removeEventListener("change", handle);
  }, [mobileOpen]);

  /* close dropdowns on Escape */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpenMenu(null);
        setMobileOpen(false);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  /* data */
  const projects = [
    {
      id: "01",
      title: "Math-To-Manim",
      desc: "A software pipeline that transforms plain-English math topics into fully rendered educational animations — without writing a single line of animation code manually.",
      img: "/images/project-math-story.webp",
      embed: "/animations/ripple-surface.html",
      role: "Systems Designer & Animator",
      problem: "Creating mathematical animations requires both deep domain knowledge and animation programming expertise — a combination few people have.",
      process: "Built a multi-stage reasoning architecture that analyzes a topic, plans scenes and camera movements, generates validated Manim/Python code, and renders the final MP4 automatically. Featured: Ripple Surface Visualization — a real-time 3D wave surface defined by z = sin(√(x² + y²)) · e^(−0.18r), rendered with WebGL and Three.js with an orbiting camera.",
      impact: "End-to-end animation pipeline from plain English to rendered video. Zero manual animation work required.",
      skills: ["Mathematical Storytelling", "Creative Technology"],
    },
    {
      id: "02",
      title: "Cinematic Content",
      desc: "Directing and editing short-form cinematic content with a focus on pacing, visual rhythm, and emotional storytelling.",
      img: "/images/project-video.webp",
      role: "Director & Editor",
      problem: "Emerging creators needed cinematic quality without the budget for a full production studio.",
      process: "Developed a modular workflow system combining careful pre-planning, deliberate pacing, and refined post-production that scales from solo to team.",
      impact: "Content reached 2M+ organic views and three pieces were featured by major streaming platforms.",
      skills: ["Design", "Creative Technology"],
    },
    {
      id: "03",
      title: "Math Education Videos",
      desc: "Creating animated math lessons that explain equations, proofs, and concepts through clean visual derivations with readable pacing.",
      img: "/images/project-math-lesson.webp",
      role: "Mathematical Animator",
      problem: "Math students struggle with abstract notation because textbooks lack visual intuition for how equations transform step by step.",
      process: "Designed a clean white-canvas style with dark text, smooth transitions between each algebraic step, and pacing tuned for comprehension over speed.",
      impact: "Two videos surpassed 500K views on academic platforms. Used as supplementary material in three university calculus courses.",
      skills: ["Mathematical Storytelling", "Frontend Engineering"],
    },
    {
      id: "04",
      title: "Editorial Writing",
      desc: "Writing long-form essays and brand narratives that combine research depth with readable, human prose.",
      img: "/images/project-writing.webp",
      role: "Writer & Editor",
      problem: "Technical publications were either too dense for general readers or too shallow for professionals.",
      process: "Developed a layered writing structure that hooks the reader first, then delivers technical depth without jargon bloat.",
      impact: "Three essays crossed 100K+ reads. One piece was cited in a university design curriculum.",
      skills: ["Design", "Creative Technology"],
    },
    {
      id: "05",
      title: "Product Design",
      desc: "Designing digital products that feel inevitable — where every interaction, transition, and empty state earns its place.",
      img: "/images/project-product.webp",
      role: "Product Designer",
      problem: "A mobile app had strong backend technology but users abandoned during onboarding due to confusing flows.",
      process: "Redesigned the onboarding and core interaction model using progressive disclosure and tactile micro-interactions.",
      impact: "Onboarding completion increased 34% and 30-day retention improved by 18% after the redesign.",
      skills: ["Design", "Frontend Engineering"],
    },
  ];

  const capabilities = [
    {
      id: "01",
      label: "Design",
      summary: "Visual systems, interfaces & identity",
      items: ["UI/UX Design", "Design Systems", "Visual Identity"],
    },
    {
      id: "02",
      label: "Frontend Engineering",
      summary: "Interfaces built with precision",
      items: ["React", "TypeScript", "Performance Optimization"],
    },
    {
      id: "03",
      label: "AI & Automation",
      summary: "Shipping intelligent products",
      items: ["AI Workflows", "Prompt Engineering", "Automation Systems"],
    },
    {
      id: "04",
      label: "Creative Technology",
      summary: "Motion, code & interactive experiences",
      items: ["Motion Design", "Creative Coding", "Interactive Experiences"],
    },
    {
      id: "05",
      label: "Mathematical Storytelling",
      summary: "Transforming abstract concepts into visual narratives",
      items: ["Manim", "NumPy", "Python", "Procedural Animation", "Mathematical Visualization"],
    },
    {
      id: "06",
      label: "Game Design",
      summary: "Worlds, mechanics & interactive play",
      items: ["Systems Design", "UX for Games", "Prototyping"],
    },
  ];

  const goMobile = (id: string) => {
    setMobileOpen(false);
    requestAnimationFrame(() => smoothScrollToId(id));
  };

  return (
    <div className="min-h-screen bg-black text-white selection:bg-white selection:text-black">

      {/* ── Scroll progress bar ───────────────────────────── */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-[1.5px] bg-white/60 z-[200] origin-left"
        style={{ scaleX: scrollYProgress }}
      />

      {/* ── Scroll to top button ──────────────────────────── */}
      <AnimatePresence>
        {showTop && (
          <motion.button
            key="scroll-top"
            onClick={() => smoothScrollTo(0)}
            className="fixed bottom-8 right-8 z-50 flex flex-col items-center gap-1.5 group cursor-pointer focus:outline-none"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            aria-label="Scroll to top"
          >
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 1.9, repeat: Infinity, ease: "easeInOut" }}
              className="text-white/45 group-hover:text-white/90 transition-colors duration-400"
            >
              <ChevronUp className="w-4 h-4" />
            </motion.div>
            <span className="font-sans text-[9px] font-light uppercase tracking-[0.18em] text-white/40 group-hover:text-white/80 transition-colors duration-400">
              Top
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* ── Cursor / ambient glows ────────────────────────── */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <motion.div
          className="absolute rounded-full"
          style={{
            width: 680, height: 680,
            x: springX, y: springY,
            translateX: "-50%", translateY: "-50%",
            background: "radial-gradient(circle, rgba(99,102,241,0.13) 0%, rgba(139,92,246,0.07) 45%, transparent 70%)",
            filter: "blur(55px)",
            willChange: "transform",
            transform: "translateZ(0)",
          }}
        />
        <motion.div
          className="absolute rounded-full"
          style={{
            width: 480, height: 480, top: "-80px", right: "-60px",
            background: "radial-gradient(circle, rgba(45,212,191,0.09) 0%, rgba(16,185,129,0.04) 50%, transparent 70%)",
            filter: "blur(70px)",
            willChange: "transform",
            transform: "translateZ(0)",
          }}
          animate={{ y: [0, 40, 0], x: [0, -30, 0] }}
          transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute rounded-full"
          style={{
            width: 360, height: 360, bottom: "10%", left: "-60px",
            background: "radial-gradient(circle, rgba(239,68,68,0.07) 0%, rgba(217,70,239,0.04) 50%, transparent 70%)",
            filter: "blur(60px)",
            willChange: "transform",
            transform: "translateZ(0)",
          }}
          animate={{ y: [0, -50, 0], x: [0, 30, 0] }}
          transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
        />
      </div>

      {/* ── Navigation ────────────────────────────────────── */}
      <nav className="fixed top-0 w-full z-50 px-6 md:px-10 h-16 flex justify-between items-center">
        <div className="absolute inset-0 bg-black/70 backdrop-blur-md border-b border-white/[0.07]" />
        <button
          onClick={() => smoothScrollTo(0)}
          className="relative font-sans font-semibold text-base tracking-tight text-white"
        >
          ematkovic.com
        </button>

        {/* Desktop nav */}
        <div className="relative hidden md:flex items-center gap-8 font-sans text-xs font-normal uppercase tracking-[0.15em]">

          {/* About */}
          <motion.button
            onClick={() => smoothScrollToId("about")}
            className="text-white/75"
            whileHover={{ color: "#ffffff", textShadow: "0 0 18px rgba(255,255,255,0.5)" }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            About
          </motion.button>

          {/* Work dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setOpenMenu("work")}
            onMouseLeave={() => setOpenMenu(null)}
          >
            <motion.button
              onClick={() => { smoothScrollToId("work"); setOpenMenu(null); }}
              onFocus={() => setOpenMenu("work")}
              onKeyDown={(e) => {
                if (e.key === "ArrowDown" || e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  setOpenMenu("work");
                }
                if (e.key === "Escape") setOpenMenu(null);
              }}
              aria-haspopup="true"
              aria-expanded={openMenu === "work"}
              className="flex items-center gap-1.5 text-white/75"
              whileHover={{ color: "#ffffff", textShadow: "0 0 18px rgba(255,255,255,0.5)" }}
              transition={{ duration: 0.3, ease: "easeOut" }}
            >
              Work
              <motion.span animate={{ rotate: openMenu === "work" ? 180 : 0 }} transition={{ duration: 0.25 }}>
                <ChevronDown className="w-3.5 h-3.5 opacity-70" />
              </motion.span>
            </motion.button>
            <AnimatePresence>
              {openMenu === "work" && (
                <motion.div
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.18, ease: "easeOut" }}
                  role="menu"
                  className="absolute top-full right-0 mt-3 w-72 bg-[#101014]/95 border border-white/15 backdrop-blur-xl py-2 rounded-xl shadow-2xl shadow-black/60"
                >
                  {projects.map((p) => (
                    <motion.button
                      key={p.id}
                      role="menuitem"
                      onClick={() => { smoothScrollToId(`project-${p.id}`); setOpenMenu(null); }}
                      className="w-full text-left px-5 py-3 text-sm normal-case tracking-normal font-normal text-white/80 hover:bg-white/[0.07]"
                      whileHover={{ color: "#ffffff", textShadow: "0 0 16px rgba(255,255,255,0.55)" }}
                      transition={{ duration: 0.25, ease: "easeOut" }}
                    >
                      {p.title}
                    </motion.button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Skills dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setOpenMenu("skills")}
            onMouseLeave={() => setOpenMenu(null)}
          >
            <motion.button
              onClick={() => { smoothScrollToId("skills"); setOpenMenu(null); }}
              onFocus={() => setOpenMenu("skills")}
              onKeyDown={(e) => {
                if (e.key === "ArrowDown" || e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  setOpenMenu("skills");
                }
                if (e.key === "Escape") setOpenMenu(null);
              }}
              aria-haspopup="true"
              aria-expanded={openMenu === "skills"}
              className="flex items-center gap-1.5 text-white/75"
              whileHover={{ color: "#ffffff", textShadow: "0 0 18px rgba(255,255,255,0.5)" }}
              transition={{ duration: 0.3, ease: "easeOut" }}
            >
              Skills
              <motion.span animate={{ rotate: openMenu === "skills" ? 180 : 0 }} transition={{ duration: 0.25 }}>
                <ChevronDown className="w-3.5 h-3.5 opacity-70" />
              </motion.span>
            </motion.button>
            <AnimatePresence>
              {openMenu === "skills" && (
                <motion.div
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.18, ease: "easeOut" }}
                  role="menu"
                  className="absolute top-full right-0 mt-3 w-60 bg-[#101014]/95 border border-white/15 backdrop-blur-xl py-2 rounded-xl shadow-2xl shadow-black/60"
                >
                  {capabilities.map((c) => (
                    <motion.button
                      key={c.id}
                      role="menuitem"
                      onClick={() => { smoothScrollToId(`skill-${c.id}`); setOpenMenu(null); }}
                      className="w-full text-left px-5 py-3 text-sm normal-case tracking-normal font-normal text-white/80 hover:bg-white/[0.07]"
                      whileHover={{ color: "#ffffff", textShadow: "0 0 16px rgba(255,255,255,0.55)" }}
                      transition={{ duration: 0.25, ease: "easeOut" }}
                    >
                      {c.label}
                    </motion.button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Contact */}
          <motion.button
            onClick={() => smoothScrollToId("contact")}
            className="text-white/75"
            whileHover={{ color: "#ffffff", textShadow: "0 0 18px rgba(255,255,255,0.5)" }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            Contact
          </motion.button>

          {/* Language switcher */}
          <div
            className="relative"
            onMouseEnter={() => setOpenMenu("lang")}
            onMouseLeave={() => setOpenMenu(null)}
          >
            <motion.button
              onFocus={() => setOpenMenu("lang")}
              onKeyDown={(e) => {
                if (e.key === "ArrowDown" || e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  setOpenMenu("lang");
                }
                if (e.key === "Escape") setOpenMenu(null);
              }}
              aria-haspopup="true"
              aria-expanded={openMenu === "lang"}
              aria-label="Change language"
              className="flex items-center gap-1.5 text-white/75"
              whileHover={{ color: "#ffffff", textShadow: "0 0 18px rgba(255,255,255,0.5)" }}
              transition={{ duration: 0.3, ease: "easeOut" }}
            >
              <Globe className="w-3.5 h-3.5 opacity-80" />
              {languages.find((l) => l.code === lang)?.short}
              <motion.span animate={{ rotate: openMenu === "lang" ? 180 : 0 }} transition={{ duration: 0.25 }}>
                <ChevronDown className="w-3.5 h-3.5 opacity-70" />
              </motion.span>
            </motion.button>
            <AnimatePresence>
              {openMenu === "lang" && (
                <motion.div
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.18, ease: "easeOut" }}
                  role="menu"
                  className="absolute top-full right-0 mt-3 w-44 bg-[#101014]/95 border border-white/15 backdrop-blur-xl py-2 rounded-xl shadow-2xl shadow-black/60"
                >
                  {languages.map((l) => (
                    <motion.button
                      key={l.code}
                      role="menuitem"
                      onClick={() => { setLang(l.code); setOpenMenu(null); }}
                      className={`w-full flex items-center justify-between px-5 py-3 text-sm normal-case tracking-normal font-normal hover:bg-white/[0.07] ${lang === l.code ? "text-white" : "text-white/70"}`}
                      whileHover={{ color: "#ffffff", textShadow: "0 0 16px rgba(255,255,255,0.55)" }}
                      transition={{ duration: 0.25, ease: "easeOut" }}
                    >
                      {l.label}
                      {lang === l.code && <span className="h-1.5 w-1.5 rounded-full bg-white" />}
                    </motion.button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>

      </nav>

      {/* Animated mobile menu toggle (morphs between hamburger and X) */}
      <motion.button
        onClick={() => setMobileOpen((v) => !v)}
        className="fixed top-0 right-6 z-[130] md:hidden h-16 flex items-center justify-center"
        aria-label={mobileOpen ? "Close menu" : "Open menu"}
        aria-expanded={mobileOpen}
        whileTap={{ scale: 0.92 }}
      >
        <motion.span
          className="flex items-center justify-center w-10 h-10 rounded-full border border-white/15 text-white/60 transition-colors duration-200 hover:text-white/90 hover:border-white/30"
          animate={mobileOpen ? { rotate: 180 } : { rotate: 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        >
          <ChevronDown className="w-4 h-4" />
        </motion.span>
      </motion.button>

      {/* ── Mobile menu overlay ───────────────────────────── */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="fixed inset-0 z-[120] md:hidden bg-black/98 backdrop-blur-2xl overflow-y-auto"
          >
            <div className="flex items-center h-16 px-6 border-b border-white/10">
              <span className="font-sans font-semibold text-base tracking-tight text-white">ematkovic.com</span>
            </div>

            <nav className="px-6 pt-8 flex flex-col gap-6">
              {[
                { label: "About", id: "about" },
                { label: "Work", id: "work" },
                { label: "Skills", id: "skills" },
                { label: "Contact", id: "contact" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => goMobile(item.id)}
                  className="text-left text-2xl font-medium tracking-tight text-white/80 active:text-white transition-colors py-2 border-b border-white/[0.06]"
                >
                  {item.label}
                </button>
              ))}

              <div className="mt-2 pl-1">
                <span className="mb-4 block text-[0.65rem] font-light uppercase tracking-[0.2em] text-white/30">Capabilities</span>
                <div className="flex flex-col gap-3">
                  {capabilities.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => goMobile(`skill-${c.id}`)}
                      className="text-left text-base font-light text-white/55 active:text-white transition-colors"
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-4">
                <span className="mb-3 block text-[0.65rem] font-light uppercase tracking-[0.2em] text-white/30">Language</span>
                <div className="flex gap-3">
                  {languages.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => setLang(l.code)}
                      className={`flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors border ${lang === l.code ? "bg-white/10 border-white/20 text-white" : "border-white/10 text-white/60 hover:bg-white/[0.04] hover:text-white/80"}`}
                    >
                      <span className="text-base">{l.flag}</span>
                      <span className="font-medium">{l.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="relative z-10 max-w-[1400px] mx-auto px-6 md:px-12 lg:px-24">

        {/* ── Hero ──────────────────────────────────────────── */}
        <section className="h-[100dvh] flex flex-col justify-center relative overflow-hidden">
          <HeroGlowLines />
          <motion.div style={{ opacity: heroOpacity, y: heroY, scale: heroScale }} className="relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            >
              <motion.h1
                className="leading-[0.9] -ml-1 md:-ml-2 font-semibold text-[#ebebeb] cursor-default"
                style={{ fontSize: "clamp(3rem, 12vw, 11rem)", letterSpacing: "-0.02em" }}
                whileHover={{ textShadow: "0 0 30px rgba(255,255,255,0.18), 0 0 60px rgba(255,255,255,0.08)" }}
                transition={{ duration: 0.6, ease: "easeOut" }}
              >
                Eugen<br />Matković
              </motion.h1>
              <motion.div
                className="mt-10 flex items-center gap-6"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1, delay: 0.5 }}
              >
                <div className="h-[1px] w-12 bg-white/25" />
                <p className="font-display text-base md:text-lg font-medium uppercase tracking-[0.05em] text-white/65">
                  Design Engineer
                </p>
              </motion.div>

              <motion.button
                onClick={() => smoothScrollToId("about")}
                className="mt-12 inline-flex items-center gap-3 rounded-full border border-white/15 bg-white/[0.03] backdrop-blur-sm pl-5 pr-4 py-2.5 group cursor-pointer focus:outline-none hover:border-white/30 hover:bg-white/[0.06] transition-colors duration-400"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.7 }}
                aria-label="Scroll to explore"
              >
                <span className="font-sans text-[0.7rem] font-normal uppercase tracking-[0.18em] text-white/55 group-hover:text-white/90 transition-colors duration-400">
                  Scroll to explore
                </span>
                <motion.div
                  animate={{ y: [0, 4, 0] }}
                  transition={{ duration: 1.9, repeat: Infinity, ease: "easeInOut" }}
                  className="text-white/40 group-hover:text-white/80 transition-colors duration-400"
                >
                  <ChevronDown className="w-4 h-4" />
                </motion.div>
              </motion.button>
            </motion.div>
          </motion.div>
        </section>

        {/* ── About ─────────────────────────────────────────── */}
        <section id="about" className="pt-32 md:pt-48 pb-0">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-8">
            <motion.div
              variants={fadeUp} initial="hidden" whileInView="show" custom={0}
              viewport={{ once: true, margin: "-80px" }}
              className="md:col-span-4 pt-1"
            >
              <SectionLabel>(01) The Ethos</SectionLabel>
            </motion.div>
            <div className="md:col-span-8 space-y-10">
              <motion.h2
                variants={fadeUp} initial="hidden" whileInView="show" custom={0.08}
                viewport={{ once: true, margin: "-80px" }}
                className="text-2xl md:text-4xl lg:text-5xl font-normal leading-[1.15] tracking-[-0.01em] text-white/95"
              >
                Anyone can ship a screen that looks right. I ship interfaces that prove it. Measured in outcomes, not impressions.
              </motion.h2>
              <motion.div
                variants={fadeUp} initial="hidden" whileInView="show" custom={0.16}
                viewport={{ once: true, margin: "-80px" }}
                className="font-sans text-base md:text-lg font-normal leading-[1.8] text-white/65 max-w-2xl space-y-5"
              >
                <p>I'm Eugen Matković, a design engineer based in Berlin. I work at the intersection of visual craft and engineering rigour, building interfaces where nothing is wasted and every detail earns its place.</p>
                <p>Fluent in English, German, and Croatian, I bring a cross-cultural sensibility to projects spanning design systems, creative technology, and intelligent automation.</p>
              </motion.div>
              <motion.div
                variants={fadeUp} initial="hidden" whileInView="show" custom={0.22}
                viewport={{ once: true, margin: "-80px" }}
                className="flex flex-wrap gap-x-12 gap-y-6 border-t border-white/10 pt-10"
              >
                {[
                  { label: "Languages",     value: "English · German · Croatian" },
                  { label: "Based in",      value: "Berlin" },
                  { label: "Available for", value: "Freelance · Full-time" },
                ].map(({ label, value }) => (
                  <div key={label}>
                    <div className="font-sans text-xs font-light uppercase tracking-[0.2em] text-white/40 mb-2">{label}</div>
                    <div className="font-sans text-sm font-medium text-white/80">{value}</div>
                  </div>
                ))}
              </motion.div>
            </div>
          </div>
          <SectionArrow targetId="work" label="Work" />
        </section>

        {/* ── Work ──────────────────────────────────────────── */}
        <section id="work" className="pt-32 md:pt-48 pb-0">
          <motion.div
            variants={fadeUp} initial="hidden" whileInView="show" custom={0}
            viewport={{ once: true, margin: "-80px" }}
            className="mb-20"
          >
            <SectionLabel>(02) Selected Works</SectionLabel>
          </motion.div>

          <div className="space-y-28 md:space-y-36">
            {projects.map((project) => (
              <motion.div
                key={project.id}
                id={`project-${project.id}`}
                initial={{ opacity: 0, scale: 0.94, filter: "blur(14px)" }}
                whileInView={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
                className="group"
              >
                <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-center">
                  <motion.div
                    className="md:col-span-7 relative cursor-pointer -mx-6 md:mx-0"
                    initial="rest"
                    whileHover="hover"
                  >
                    {/* Soft light-colored background glow blur behind the image */}
                    <motion.div
                      className="absolute -inset-4 md:-inset-8 pointer-events-none rounded-[2rem]"
                      style={{
                        background:
                          "radial-gradient(ellipse at 50% 45%, rgba(186,230,253,0.45) 0%, rgba(221,214,254,0.32) 38%, rgba(251,207,232,0.22) 60%, rgba(255,255,255,0) 78%)",
                        filter: "blur(48px)",
                        willChange: "transform, opacity",
                        transform: "translateZ(0)",
                      }}
                      variants={{ rest: { opacity: 0, scale: 0.92 }, hover: { opacity: 1, scale: 1 } }}
                      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                    />

                    {/* Image / embed container */}
                    <motion.div
                      className="overflow-hidden rounded-none md:rounded-2xl bg-[#060a12] relative aspect-[16/10]"
                      variants={{ rest: { scale: 1 }, hover: { scale: 1.03 } }}
                      transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
                    >
                      {project.embed ? (
                        <iframe
                          src={project.embed}
                          title={project.title}
                          className="w-full h-full border-0 rounded-none md:rounded-2xl"
                          allow="accelerometer"
                          loading="lazy"
                        />
                      ) : (
                        <motion.img
                          src={project.img}
                          alt={project.title}
                          loading="lazy"
                          decoding="async"
                          className="w-full h-full object-cover rounded-none md:rounded-2xl"
                          variants={{ rest: { opacity: 0.65, scale: 1 }, hover: { opacity: 1, scale: 1.04 } }}
                          transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
                        />
                      )}
                    </motion.div>
                  </motion.div>
                  <div className="md:col-span-5 flex flex-col justify-center">
                    <div className="font-sans text-xs font-light uppercase tracking-[0.18em] text-white/40 mb-5">{project.id} — {project.role}</div>
                    <h3 className="text-xl md:text-2xl lg:text-3xl font-bold tracking-[-0.02em] mb-4 text-white">{project.title}</h3>
                    <p className="font-sans text-sm font-normal text-white/60 mb-6 max-w-sm leading-[1.7]">{project.desc}</p>
                    <div className="space-y-4 mb-8 border-t border-white/10 pt-6 max-w-md">
                      {[
                        { label: "Problem", value: project.problem, accent: false },
                        { label: "Process", value: project.process, accent: false },
                        { label: "Impact",  value: project.impact,  accent: true  },
                      ].map((row) => (
                        <div key={row.label} className="grid grid-cols-[4.5rem_1fr] gap-4">
                          <div className="font-sans text-[0.65rem] font-light uppercase tracking-[0.2em] text-white/35 pt-[0.15rem]">{row.label}</div>
                          <div className={`font-sans text-sm leading-[1.6] ${row.accent ? "text-white/90 font-medium" : "text-white/60 font-normal"}`}>{row.value}</div>
                        </div>
                      ))}
                    </div>
                    {project.skills && (
                      <div className="flex flex-wrap gap-2 mb-7">
                        {project.skills.map((skill) => (
                          <motion.button
                            key={skill}
                            onClick={() => smoothScrollToId("skills")}
                            className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-[0.65rem] font-light uppercase tracking-[0.15em] text-white/50 hover:border-white/25 hover:text-white/80 transition-colors duration-300"
                            whileHover={{ y: -1 }}
                            transition={{ duration: 0.2 }}
                          >
                            {skill}
                          </motion.button>
                        ))}
                      </div>
                    )}
                    <motion.button
                      onClick={() => smoothScrollToId("skills")}
                      className="inline-flex items-center gap-3 font-sans text-xs font-normal uppercase tracking-[0.18em] w-fit text-white/40 hover:text-white transition-colors duration-300"
                      whileHover={{ color: "#ffffff" }}
                      transition={{ duration: 0.5, ease: "easeOut" }}
                    >
                      Explore Skills
                      <span className="inline-flex">
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </span>
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          <SectionArrow targetId="skills" label="Skills" />
        </section>

        {/* ── Skills / Capabilities ─────────────────────────── */}
        <section id="skills" className="pt-32 md:pt-48 pb-0 border-t border-white/10 mt-20 md:mt-28">
          <motion.div
            variants={fadeUp} initial="hidden" whileInView="show" custom={0}
            viewport={{ once: true, margin: "-80px" }}
            className="mb-16"
          >
            <SectionLabel>(03) Capabilities</SectionLabel>
          </motion.div>

          <div className="divide-y divide-white/[0.06]">
            {capabilities.map((cap, i) => (
              <motion.div
                key={cap.id}
                id={`skill-${cap.id}`}
                variants={fadeUp} initial="hidden" whileInView="show" custom={i * 0.07}
                viewport={{ once: true, margin: "-60px" }}
                className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8 py-6 md:py-7 items-center"
              >
                <div className="md:col-span-4 flex items-center gap-4">
                  <span className="font-sans text-[10px] font-light text-white/20 tracking-widest tabular-nums">{cap.id}</span>
                  <h3 className="text-sm font-medium tracking-tight text-white/80">
                    {cap.label}
                  </h3>
                </div>
                <div className="md:col-span-8 flex flex-wrap gap-x-8 gap-y-1.5">
                  {cap.items.map((item) => (
                    <motion.span
                      key={item}
                      className="text-sm font-light text-white/60 cursor-default"
                      whileHover={{
                        color: "rgba(255,255,255,1)",
                        textShadow: "0 0 12px rgba(255,255,255,0.5), 0 0 30px rgba(255,255,255,0.2)",
                      }}
                      transition={{ duration: 0.3, ease: "easeOut" }}
                    >
                      {item}
                    </motion.span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>

          <SectionArrow targetId="contact" label="Contact" />
        </section>

        {/* ── Contact ───────────────────────────────────────── */}
        <section id="contact" className="py-32 md:py-48 border-t border-white/10 mt-20 md:mt-28">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-8">
            <motion.div
              variants={fadeUp} initial="hidden" whileInView="show" custom={0}
              viewport={{ once: true, margin: "-80px" }}
              className="md:col-span-4"
            >
              <SectionLabel>(04) Connect</SectionLabel>
            </motion.div>
            <div className="md:col-span-8">
              <motion.h2
                variants={fadeUp} initial="hidden" whileInView="show" custom={0.08}
                viewport={{ once: true, margin: "-80px" }}
                className="text-3xl md:text-5xl lg:text-6xl font-normal tracking-[-0.02em] leading-[1.1] mb-14 text-white"
              >
                Let's build something<br />uncompromising.
              </motion.h2>

              <motion.div
                variants={fadeUp} initial="hidden" whileInView="show" custom={0.16}
                viewport={{ once: true, margin: "-80px" }}
              >
                <MotionA
                  href="mailto:eugenmatkovicc@gmail.com"
                  className="group inline-flex items-center gap-3 md:gap-4 text-base sm:text-lg md:text-2xl font-light tracking-tight text-white/60 mb-20 break-all"
                  initial={{ opacity: 0.6 }}
                  whileHover={{ opacity: 1, color: "#ffffff" }}
                  transition={{ duration: 0.55, ease: "easeOut" }}
                >
                  eugenmatkovicc@gmail.com
                  <ArrowUpRight className="w-5 h-5 md:w-6 md:h-6 shrink-0 transition-transform duration-500 group-hover:translate-x-2 group-hover:-translate-y-2" />
                </MotionA>
              </motion.div>

              <motion.div
                variants={fadeUp} initial="hidden" whileInView="show" custom={0.22}
                viewport={{ once: true, margin: "-80px" }}
                className="flex flex-wrap gap-x-8 gap-y-4 border-t border-white/10 pt-12"
              >
                {[
                  { Icon: Facebook,  label: "Facebook",  color: "#1877F2", href: "https://facebook.com" },
                  { Icon: Instagram, label: "Instagram", color: "#E1306C", href: "https://instagram.com" },
                  { Icon: Linkedin,  label: "LinkedIn",  color: "#0A66C2", href: "https://linkedin.com" },
                ].map(({ Icon, label, color, href }) => (
                  <MotionA
                    key={label}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`Visit ${label}`}
                    className="font-sans text-xs font-normal uppercase tracking-[0.18em] text-white/55 flex items-center gap-2"
                    initial={{ opacity: 0.6 }}
                    whileHover={{ opacity: 1, color: "#ffffff" }}
                    transition={{ duration: 0.5, ease: "easeOut" }}
                  >
                    <Icon
                      className="w-4 h-4"
                      style={{ color, filter: `drop-shadow(0 0 6px ${color}99)` }}
                    />
                    {label}
                  </MotionA>
                ))}
              </motion.div>
            </div>
          </div>
        </section>

      </main>
    </div>
  );
}
